
# API Documentation

## 1. DNS 데이터 호출
5. 전체 취약점 목록 호출
메뉴: Asset List > Asset Details > Risk
URI: /risk/all_vuln_list/
Method: GET
Options:
page (선택적): 페이지네이션 처리 (기본값: 1)

6. 취약점 상세 결과 호출
메뉴: Risk Management > Risk List > Risk Detail
URI: /risk/vuln_detail/?idx=1
Method: GET
매개변수 : idx (필수)

7. 카테고리별 취약점 개수 호출
메뉴: Asset List > Asset Details > Risk 그림
URI: /risk/category_result/
Method: GET

8. 리스크별 취약점 개수 호출
메뉴: Asset List > Asset Details > Risk 표
URI: /risk/risk_result/
Method: GET

9. IP별 취약점 개수 호출
메뉴: Asset List (Vuln 컬럼)
URI: /risk/ip_result/
Method: GET

# API(Assets)
## 1. Asset List 호출
* URI: /asset/list?page=1

* Method: GET

* Options:
    * page(필수X): 페이지네이션 처리(default: 1)

## 2. Asset Count 호출
* URI: /asset/count

* Method: GET

## 3. Asset Detail 호출
* URI: /asset/detail?ip=1.1.1.1

* Method: GET

* Options:
    * ip(필수O): 검색할 ip

## 4. Asset > Risk List 호출
* URI: /asset/risk/list?ip=1.1.1.1

* Method: GET

* Options:
    * ip(필수O): 검색할 ip


## 5. Risk List 호출
* URI: /asset/risk/list?page=1

* Method: GET

* Options:
    * page(필수X): 페이지네이션 처리(default: 1)


## 6. Risk Detail 호출
* URI: /asset/risk/detail?idx=130_1

* Method: GET

* Options:


# django guide

## django start
    python manage.py runserver

## DBMS Config Setting
    setting.py 내부 수정

## model updated (models.py 규격 자동 생성)
    python manage.py inspectdb > models.py

## DBMS migration (DBMS 관련 데이터 업데이트가 있는 경우 아래 명령어 실행)
    python manage.py makemigrations
    python manage.py migrate

## 디렉토리 생성 관련
    1. python manage.py startapp {name}
    2. 생성된 디렉터리에 serializers.py, urls.py 생성(api\\ 경로에 있는 파일 복사해도 됨)
    3. api_server\\settings.py 내부 INSTALLED_APPS에 생성된 디렉터리 추가
    4. api_server\\urls.py 내부 urlpatterns에 라우팅 처리 코드 추가
    6. 생성된 디렉터리에서 개발 진행

</br>
</br>



# 현재 사용안되는 API 리스트
메뉴 X
URI /risk/dns/
Method: GET
Options:
page` (선택적): 페이지네이션 처리 (기본값: 5)

2. Domain 데이터 호출
메뉴: X
URI: /risk/domain/
Method: GET
Options:
page (선택적): 페이지네이션 처리 (기본값: 5)

3. Git 데이터 호출
메뉴: X
URI: /risk/git/
Method: GET
Options:
page (선택적): 페이지네이션 처리 (기본값: 1)

4. SSL 데이터 호출
메뉴: X
URI: /risk/ssl/
Method: GET
Options:
page (선택적): 페이지네이션 처리 (기본값: 1)