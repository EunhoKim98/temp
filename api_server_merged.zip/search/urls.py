from django.urls import path
from . import views 

urlpatterns = [
    path('input_domain/', views.input_domain, name='input_domain')
]
