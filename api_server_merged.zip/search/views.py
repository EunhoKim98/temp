from django.http import JsonResponse
from rest_framework.decorators import api_view
from django.core.validators import URLValidator, validate_ipv4_address
from django.core.exceptions import ValidationError
import requests

def request_flask(domain):
    res = requests.get(url=f'http://test.com?domain={domain}')
    if res.status_code != 200:
        print("Flask Request ERROR")

@api_view(['GET'])
def input_domain(request):
    domain = request.GET.get('domain', '').strip()
    
    if not domain.startswith(('http://', 'https://')):
        domain = 'http://' + domain

    url_validator = URLValidator()
    domain_name = domain.split('//')[-1]  # 프로토콜 제거

    try:
         # 도메인 유효성 검증
        url_validator(domain)
        
        #Flask 서버에 요청
        #request_flask(domain_name)
        return JsonResponse({"status": "ok", "message": "success"})
    except ValidationError:
        pass 

    # IP 유효성 검증
    try:
        validate_ipv4_address(domain_name) 
        
        #Flask 서버에 요청
        #request_flask(domain_name)
        return JsonResponse({"status": "ok", "message": "success"})
    except ValidationError:
        pass  # IP가 유효하지 않으면 오류 메시지 반환

    return JsonResponse({"status": "error", "message": "Invalid IP address or Domain"})
