# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    id = models.BigAutoField(primary_key=True)
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'

class Cen(models.Model):
    engine = models.TextField(blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    ip = models.TextField(blank=True, null=True)
    port = models.TextField(blank=True, null=True)
    sha1 = models.TextField(blank=True, null=True)
    sha256 = models.TextField(blank=True, null=True)
    test = models.TextField(blank=True, null=True)
    latitude = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'cen'


class Censys(models.Model):
    keyword = models.TextField(blank=True, null=True)
    ip = models.TextField(blank=True, null=True)
    port = models.TextField(blank=True, null=True)
    protocol = models.TextField(blank=True, null=True)
    domains = models.TextField(blank=True, null=True)
    os = models.TextField(blank=True, null=True)
    product = models.TextField(blank=True, null=True)
    country_name = models.TextField(blank=True, null=True)
    city = models.TextField(blank=True, null=True)
    data = models.TextField(blank=True, null=True)
    cn = models.TextField(db_column='CN', blank=True, null=True)  # Field name made lowercase.
    versions = models.TextField(blank=True, null=True)
    sha256 = models.TextField(blank=True, null=True)
    serial = models.TextField(blank=True, null=True)
    robots = models.TextField(blank=True, null=True)
    favicon_hash = models.TextField(blank=True, null=True)
    vulns = models.TextField(blank=True, null=True)
    desc = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'censys'



class Fofa(models.Model):
    ip = models.TextField(blank=True, null=True)
    port = models.TextField(blank=True, null=True)
    protocol = models.TextField(blank=True, null=True)
    country = models.TextField(blank=True, null=True)
    country_name = models.TextField(blank=True, null=True)
    region = models.TextField(blank=True, null=True)
    city = models.TextField(blank=True, null=True)
    longitude = models.TextField(blank=True, null=True)
    latitude = models.TextField(blank=True, null=True)
    as_number = models.TextField(blank=True, null=True)
    as_organization = models.TextField(blank=True, null=True)
    host = models.TextField(blank=True, null=True)
    domain = models.TextField(blank=True, null=True)
    os = models.TextField(blank=True, null=True)
    server = models.TextField(blank=True, null=True)
    icp = models.TextField(blank=True, null=True)
    title = models.TextField(blank=True, null=True)
    jarm = models.TextField(blank=True, null=True)
    header = models.TextField(blank=True, null=True)
    banner = models.TextField(blank=True, null=True)
    cert = models.TextField(blank=True, null=True)
    base_protocol = models.TextField(blank=True, null=True)
    link = models.TextField(blank=True, null=True)
    certs_issuer_org = models.TextField(blank=True, null=True)
    certs_issuer_cn = models.TextField(blank=True, null=True)
    certs_subject_org = models.TextField(blank=True, null=True)
    certs_subject_cn = models.TextField(blank=True, null=True)
    tls_ja3s = models.TextField(blank=True, null=True)
    tls_version = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'fofa'


class Shodan(models.Model):
    info = models.TextField(blank=True, null=True)
    product = models.TextField(blank=True, null=True)
    http = models.TextField(blank=True, null=True)
    os = models.TextField(blank=True, null=True)
    asn = models.TextField(blank=True, null=True)
    tags = models.TextField(blank=True, null=True)
    timestamp = models.TextField(blank=True, null=True)
    isp = models.TextField(blank=True, null=True)
    transport = models.TextField(blank=True, null=True)
    field_shodan = models.TextField(db_column='_shodan', blank=True, null=True)  # Field renamed because it started with '_'.
    hash = models.FloatField(blank=True, null=True)
    ssl = models.TextField(blank=True, null=True)
    hostnames = models.TextField(blank=True, null=True)
    location = models.TextField(blank=True, null=True)
    ip = models.FloatField(blank=True, null=True)
    domains = models.TextField(blank=True, null=True)
    org = models.TextField(blank=True, null=True)
    data = models.TextField(blank=True, null=True)
    port = models.FloatField(blank=True, null=True)
    opts = models.TextField(blank=True, null=True)
    ip_str = models.TextField(blank=True, null=True)
    cloud = models.TextField(blank=True, null=True)
    cpe23 = models.TextField(blank=True, null=True)
    cpe = models.TextField(blank=True, null=True)
    version = models.TextField(blank=True, null=True)
    vulns = models.TextField(blank=True, null=True)
    ntlm = models.TextField(blank=True, null=True)
    ntp = models.TextField(blank=True, null=True)
    ipv6 = models.TextField(blank=True, null=True)
    stun = models.TextField(blank=True, null=True)
    ftp = models.TextField(blank=True, null=True)
    collect_datetime = models.TextField(blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    synology_dsm = models.TextField(blank=True, null=True)
    mac = models.TextField(blank=True, null=True)
    draytek_vigor = models.TextField(blank=True, null=True)
    snmp = models.TextField(blank=True, null=True)
    match = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'shodan'


class ShodanDup(models.Model):
    idx = models.AutoField(primary_key=True)
    ip = models.FloatField(blank=True, null=True)
    port = models.FloatField(blank=True, null=True)
    hostnames = models.TextField(blank=True, null=True)
    info = models.TextField(blank=True, null=True)
    product = models.TextField(blank=True, null=True)
    http = models.TextField(blank=True, null=True)
    os = models.TextField(blank=True, null=True)
    asn = models.TextField(blank=True, null=True)
    tags = models.TextField(blank=True, null=True)
    timestamp = models.TextField(blank=True, null=True)
    isp = models.TextField(blank=True, null=True)
    transport = models.TextField(blank=True, null=True)
    field_shodan = models.TextField(db_column='_shodan', blank=True, null=True)  # Field renamed because it started with '_'.
    hash = models.FloatField(blank=True, null=True)
    ssl = models.TextField(blank=True, null=True)
    location = models.TextField(blank=True, null=True)
    domains = models.TextField(blank=True, null=True)
    org = models.TextField(blank=True, null=True)
    data = models.TextField(blank=True, null=True)
    opts = models.TextField(blank=True, null=True)
    ip_str = models.TextField(blank=True, null=True)
    cloud = models.TextField(blank=True, null=True)
    cpe23 = models.TextField(blank=True, null=True)
    cpe = models.TextField(blank=True, null=True)
    version = models.TextField(blank=True, null=True)
    vulns = models.TextField(blank=True, null=True)
    ntlm = models.TextField(blank=True, null=True)
    ntp = models.TextField(blank=True, null=True)
    ipv6 = models.TextField(blank=True, null=True)
    stun = models.TextField(blank=True, null=True)
    ftp = models.TextField(blank=True, null=True)
    collect_datetime = models.TextField(blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    synology_dsm = models.TextField(blank=True, null=True)
    mac = models.TextField(blank=True, null=True)
    draytek_vigor = models.TextField(blank=True, null=True)
    snmp = models.TextField(blank=True, null=True)
    match = models.TextField(blank=True, null=True)
    

    class Meta:
        managed = False
        db_table = 'shodan_dup'


class Total(models.Model):
    engine = models.TextField(blank=True, null=True)
    keyword = models.TextField(blank=True, null=True)
    ip = models.TextField(blank=True, null=True)
    port = models.TextField(blank=True, null=True)
    sha1 = models.TextField(blank=True, null=True)
    sha256 = models.TextField(blank=True, null=True)
    test = models.TextField(blank=True, null=True)
    latitude = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'total'

