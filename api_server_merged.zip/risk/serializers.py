from rest_framework.serializers import ModelSerializer
from .models import  Dns, Domain, Git, Ssl, VulnDetail, VulnList 


class DnsSerializer(ModelSerializer):
    class Meta:
        model = Dns
        fields = '__all__'

class DomainSerializer(ModelSerializer):
    class Meta:
        model = Domain
        fields = '__all__'

class GitSerializer(ModelSerializer):
    class Meta:
        model = Git
        fields = '__all__'

class SslSerializer(ModelSerializer):
    class Meta:
        model = Ssl
        fields = '__all__'

class VulnDetailSerializer(ModelSerializer):
    class Meta:
        model = VulnDetail
        fields = '__all__'

class VulnListSerializer(ModelSerializer):
    class Meta:
        model = VulnList
        fields = '__all__'
