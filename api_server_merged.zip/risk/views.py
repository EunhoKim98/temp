from rest_framework.decorators import api_view
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from django.db.models import F
from .models import Dns, Domain, Git, Ssl, VulnDetail, VulnList
from .serializers import DnsSerializer, DomainSerializer, GitSerializer, SslSerializer, VulnDetailSerializer, VulnListSerializer
from pprint import pprint
from rest_framework import status

PAGE_SIZE = 10

#각 IP별 취약점 개수 및 가장 높은 위험 수준을 구하는 함수
#Args: serializer (list): 직렬화된 취약점 데이터의 리스트.
#Returns: list: 각 IP별 취약점 개수와 가장 높은 위험 수준이 포함된 딕셔너리 리스트.
def count_vulnerabilities_by_ip(serializer):
    risk_order = {
        'Critical': 4,
        'High': 3,
        'Medium': 2,
        'Low': 1,
    }

    ip_counts = {}

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        ip = record['ip']
        risk = record.get('risk', 'Low')

        if ip not in ip_counts:
            ip_counts[ip] = {
                'vulnerability_count': 0,
                'highest_risk': 0
            }

        ip_counts[ip]['vulnerability_count'] += 1

        ip_counts[ip]['highest_risk'] = max(ip_counts[ip]['highest_risk'], risk_order.get(risk, 0))

    # 위험 수준에 따라 이름의 첫 글자로 변환
    risk_mapping = {v: k[0] for k, v in risk_order.items()}

    return [{'ip': ip,
            'vulnerability_count': data['vulnerability_count'],
            'highest_risk': risk_mapping.get(data['highest_risk'], 'N')}
        for ip, data in ip_counts.items()]

#IP별 취약점 개수를 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: IP별 취약점 개수가 포함된 JSON 응답.
@api_view(['GET'])
def get_ip_counts_view(request):
    VulnList_records = combine_vuln_list_detail()
    serializer = serialize_vuln_records(VulnList_records)
    ip_counts = count_vulnerabilities_by_ip(serializer)
    return Response(ip_counts)

#각 카테고리별 취약점 개수를 구하는 함수
#    Args: serializer (list): 직렬화된 취약점 데이터의 리스트.
#    Returns: dict: 카테고리별 취약점 개수가 포함된 딕셔너리.
def count_vulnerabilities_by_category(serializer):
    categories = ['ssl', 'host', 'domain', 'etc', 'cloud', 'application']

    # 카테고리별 카운트를 초기화
    category_counts = {category: 0 for category in categories}

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        category = record.get('category')
        if category in category_counts:
            category_counts[category] += 1

    return category_counts

#카테고리별 취약점 개수를 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: 카테고리별 취약점 개수가 포함된 JSON 응답.
@api_view(['GET'])
def get_category_counts_view(request):
    VulnList_records = combine_vuln_list_detail()
    serializer = serialize_vuln_records(VulnList_records)
    category_counts = count_vulnerabilities_by_category(serializer)
    return Response(category_counts)

#각 카테고리와 리스크 조합으로 취약점 개수를 구하는 함수
#    Args: serializer (list): 직렬화된 취약점 데이터의 리스트.
#    Returns: dict: 리스크별 총 카운트 및 상세 카운트가 포함된 딕셔너리.
def count_vulnerabilities_by_risk(serializer):
    risk_levels = ['Critical', 'High', 'Medium', 'Low']
    categories = ['ssl', 'host', 'domain', 'etc', 'cloud']

    # 총 카운트 및 상세 카운트 초기화
    total_counts = {f"{risk.lower()}_total_count": 0 for risk in risk_levels}
    detail_counts = {f"{risk.lower()}_{category.lower()}_count": 0 for risk in risk_levels for category in categories}
    detail_counts.update({f"{risk.lower()}_application_count": 0 for risk in risk_levels})

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        risk = record.get('risk')  # risk 필드 가져오기
        category = record.get('category')  # category 필드 가져오기

        if risk in risk_levels:
            total_counts[f"{risk.lower()}_total_count"] += 1

            if category in categories:
                detail_counts[f"{risk.lower()}_{category.lower()}_count"] += 1

            # application 카운트 추가
            if category in ['application(Web)', 'application(Mobile)']:
                detail_counts[f"{risk.lower()}_application_count"] += 1

    return {
        'total_counts': total_counts,
        'detail_counts': detail_counts
    }

#리스크별 취약점 개수를 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: 리스크별 취약점 개수가 포함된 JSON 응답.
@api_view(['GET'])
def get_risk_counts_view(request):
    VulnList_records = combine_vuln_list_detail()
    serializer = serialize_vuln_records(VulnList_records)

    # 리스크별 취약점 개수 계산
    risk_counts = count_vulnerabilities_by_risk(serializer)

    return Response(risk_counts, status=200)  # 결과를 반환

#전체 취약점 목록을 페이지네이션하여 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: 전체 취약점 목록이 포함된 JSON 응답.
@api_view(['GET'])
def get_all_vuln_list(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    VulnList_records = VulnList.objects.filter(threat_id__in=VulnDetail.objects.values('threat_id')).annotate(
        title=VulnDetail.objects.filter(threat_id=F('threat_id')).values('title')[:1]
    )

    result_page = paginator.paginate_queryset(VulnList_records, request)

    serializer = []
    for record in result_page:
        record_data = {
            "ip": record.ip,
            "port": record.port,
            "domain": record.domain,
            "category": record.category,
            "title": record.title,
            "raw_data": record.raw_data,
            "issue_status": record.issue_status,
            "screenshot": record.screenshot,
            "datetime": record.datetime,
        }
        serializer.append(record_data)

    return paginator.get_paginated_response(serializer)

#IDX별 취약점 상세 결과를 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: 특정 IDX에 해당하는 취약점 상세 정보가 포함된 JSON 응답.
@api_view(['GET'])
def get_vuln_by_idx(request):
    idx = request.query_params.get('idx')

    if idx is None:
        return Response({"detail": "idx parameter is required."}, status=status.HTTP_400_BAD_REQUEST)

    try:
        # 해당 idx에 맞는 취약점 상세 정보 조회
        vuln_record = VulnList.objects.get(pk=idx)

        # VulnList와 VulnDetail을 조인하여 레코드 가져오기
        vuln_detail = combine_vuln_list_detail().filter(pk=idx).first()

        if vuln_detail is None:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        # 데이터를 직렬화
        serialized_data = serialize_vuln_records([vuln_detail])

        return Response(serialized_data[0], status=status.HTTP_200_OK)

    except VulnList.DoesNotExist:
        return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

#DNS 데이터를 페이지네이션하여 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: DNS 데이터가 포함된 JSON 응답.
@api_view(['GET'])
def get_dns_data(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE
    dns_records = Dns.objects.all()

    result_page = paginator.paginate_queryset(dns_records, request)
    serializer = DnsSerializer(result_page, many=True)
    return paginator.get_paginated_response(serializer.data)

#Domain 데이터를 페이지네이션하여 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: Domain 데이터가 포함된 JSON 응답.
@api_view(['GET'])
def get_domain_data(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE
    domain_records = Domain.objects.all()

    result_page = paginator.paginate_queryset(domain_records, request)
    serializer = DomainSerializer(result_page, many=True)
    return paginator.get_paginated_response(serializer.data)

#SSL 데이터를 페이지네이션하여 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: SSL 데이터가 포함된 JSON 응답.
@api_view(['GET'])
def get_ssl_data(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE
    ssl_records = Ssl.objects.all()

    result_page = paginator.paginate_queryset(ssl_records, request)
    serializer = SslSerializer(result_page, many=True)
    return paginator.get_paginated_response(serializer.data)

#Git 데이터를 페이지네이션하여 반환하는 API 뷰
#    Args: request: HTTP 요청 객체.
#    Returns: Response: Git 데이터가 포함된 JSON 응답.
@api_view(['GET'])
def get_git_data(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE
    git_records = Git.objects.all()

    result_page = paginator.paginate_queryset(git_records, request)
    serializer = GitSerializer(result_page, many=True)
    return paginator.get_paginated_response(serializer.data)

#ulnList와 VulnDetail을 조인하여 레코드를 가져오는 함수
#   Returns: QuerySet: 조인된 VulnList와 VulnDetail 데이터가 포함된 쿼리셋.
def combine_vuln_list_detail():
    VulnList_records = VulnList.objects.filter(
        threat_id__in=VulnDetail.objects.values('threat_id')
    ).values(
        "threat_id",
        "ip",
        "port",
        "domain",
        "category",
        "raw_data",
        "issue_status",
        "screenshot",
        "datetime"
    ).annotate(
        title=VulnDetail.objects.filter(threat_id=F('threat_id')).values('title')[:1],
        description=VulnDetail.objects.filter(threat_id=F('threat_id')).values('description')[:1],
        security_advisory=VulnDetail.objects.filter(threat_id=F('threat_id')).values('security_advisory')[:1],
        impact=VulnDetail.objects.filter(threat_id=F('threat_id')).values('impact')[:1],
        risk=VulnDetail.objects.filter(threat_id=F('threat_id')).values('risk')[:1],
        cve=VulnDetail.objects.filter(threat_id=F('threat_id')).values('cve')[:1],
        exploit=VulnDetail.objects.filter(threat_id=F('threat_id')).values('exploit')[:1],
    )

    return VulnList_records

#VulnList와 VulnDetail 데이터를 직렬화하는 함수
#    Args:records: 조인된 레코드의 리스트.
#    Returns: list: 직렬화된 데이터의 리스트.
def serialize_vuln_records(records):
    serializer = []
    for record in records:
        record_data = {
            "threat_id": record['threat_id'],  # values()로 가져온 데이터는 딕셔너리 형태입니다.
            "ip": record['ip'],
            "port": record['port'],
            "domain": record['domain'],
            "category": record['category'],
            "raw_data": record['raw_data'],
            "issue_status": record['issue_status'],
            "screenshot": record['screenshot'],
            "datetime": record['datetime'],
            "title": record.get('title', None),  # 키가 없을 수 있으므로 get() 사용
            "risk": record.get('risk', None),
            "description": record.get('description', None),
            "security_advisory": record.get('security_advisory', None),
            "impact": record.get('impact', None),
            "cve": record.get('cve', None),
            "exploit": record.get('exploit', None),
        }

        serializer.append(record_data)
    return serializer
