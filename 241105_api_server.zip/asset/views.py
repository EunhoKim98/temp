from rest_framework.decorators import api_view
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from django.db.models import F
from pprint import pprint
from .utils import *
from .services import *

PAGE_SIZE = 10

# Asset List
@api_view(['GET'])
def getAssetList(request):
    paginator = PageNumberPagination()
    paginator.page_size = 100 # 페이지당 X개 노출

    grouped_data_list = getAssetListService()
    
    # 페이지네이션 처리
    result_page = paginator.paginate_queryset(grouped_data_list, request)
    
    # DBMS Speed Debugging
    query_logging()

    return paginator.get_paginated_response(result_page)

# Asset List Count
@api_view(['GET'])
def getAssetCount(request):
    paginator = PageNumberPagination()
    paginator.page_size = 100 # 페이지당 X개
    
    result = getAssetCountService()
    
    res = {
        'results': result
    }
    
    # DBMS Speed Debugging
    query_logging()
    
    return Response(res)

# Asset List > Asset Details
@api_view(['GET'])
def getAssetDetails(request):
    
    ip = request.GET.get('ip', None)
    
    grouped_data_list = getAssetDetailsService(ip)

    # DBMS Speed Debugging
    query_logging()

    res = {
        'results': grouped_data_list
    }
    return Response(res)

# Asset List > Asset Details > Risk
@api_view(['GET'])
def getAssetRiskList(request):
    ip = request.GET.get('ip', None)
    
    paginator = PageNumberPagination()
    paginator.page_size = 100 # 페이지당 X개 노출

    result = getAssetRiskListService(ip)

    # 페이지네이션 처리
    result_page = paginator.paginate_queryset(result, request)

    # DBMS Speed Debugging
    query_logging()

    return paginator.get_paginated_response(result_page)


# Risk Management
@api_view(['GET'])
def getRiskList(request):
    paginator = PageNumberPagination()
    paginator.page_size = 100 # 페이지당 X개 노출

    result = getRiskListService()

    # 페이지네이션 처리
    result_page = paginator.paginate_queryset(result, request)

    # DBMS Speed Debugging
    query_logging()

    return paginator.get_paginated_response(result_page)

# Risk Management > Detail
@api_view(['GET'])
def getRiskDetail(request):
    ip = request.GET.get('ip', None)
    port = request.GET.get('port', None)
    title = request.GET.get('title', None)
    idx = request.GET.get('idx', None)

    result = getRiskDetailService(ip, port, title, idx)
    
    res = {
        'results': result
    }
    
    # DBMS Speed Debugging
    query_logging()
    
    return Response(res)



