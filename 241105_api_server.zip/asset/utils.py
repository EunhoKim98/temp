from django.db import connection

# DBMS에 저장된 불필요한 값 공백 처리(nan, None)
def clean_data(item):
    for field, value in item.__dict__.items():
        if field == '_state':
            continue
            
        if value is None or value == 'None' or value == 'nan':
            setattr(item, field, "")
            
# SQL Query 디버깅, 속도테스트
def query_logging():
    print("Executed queries:")
    for query in connection.queries:
        print(query)