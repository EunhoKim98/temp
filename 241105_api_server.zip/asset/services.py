from .models import ShodanDup, AssetList
import json
from collections import defaultdict
import ast
from .utils import *

def getAssetListService():
    # 데이터 필터링
    datas = AssetList.objects.filter(match='O').only("ip_str", "hostnames", "org", "location", "port", "vulns", "tags", "collect_datetime").order_by('idx')
    
    # ip_str를 기준으로 그룹화하기 위한 딕셔너리
    grouped_data = defaultdict(lambda: {
        "ip_str": None,
        "hostnames": None,
        "org": None,
        "country": None,
        "vuln": None,
        "tags": None,
        "collect_datetime": None,
        "ports": []  # port들을 저장할 배열
    })
    
    ip_str = ''
    # 데이터를 가공하여 ip_str를 기준으로 그룹화
    for item in datas:
        clean_data(item)
        
        ip_str = item.ip_str
        
        # 처음 등장한 ip_str의 경우 기본 데이터를 채워줌
        if grouped_data[ip_str]['ip_str'] is None:
            risk_level = {'Unknown': 0, 'Low': 0, 'Medium': 0, 'High': 0, 'Critical': 0, 'Total': 0}
            grouped_data[ip_str]['ip_str'] = item.ip_str
            arr_hostnames = ast.literal_eval(item.hostnames)
            grouped_data[ip_str]['hostnames'] = arr_hostnames
            grouped_data[ip_str]['org'] = item.org
            if item.location != "":
                location_json = json.loads(item.location)
                grouped_data[ip_str]['country'] = location_json.get('country_name', None)
            if item.tags != "":
                arr_tags = ast.literal_eval(item.tags)
                grouped_data[ip_str]['tags'] = arr_tags
            grouped_data[ip_str]['collect_datetime'] = item.collect_datetime
            grouped_data[ip_str]['risk_level'] = risk_level
        else:
            risk_level = grouped_data[ip_str]['risk_level']
        
        # 취약점 파싱
        if item.vulns != "":
            vulns_json = json.loads(item.vulns)
            for cve_id, cve_data in vulns_json.items():
                risk_score = cve_data['cvss_v2']
                risk = "Unknown"
                if risk_score != None:
                    if risk_score <= 3.9:
                        risk = 'Low'
                    elif risk_score > 3.9 and risk_score <= 6.9:
                        risk = 'Medium'
                    elif risk_score > 6.9 and risk_score <= 8.9:
                        risk = 'High'
                    elif risk_score > 8.9:
                        risk = 'Critical'
                risk_level[risk] += 1
                risk_level['Total'] += 1
                    
        # port 값을 배열에 추가
        if item.port != "":
            grouped_data[ip_str]['ports'].append(int(item.port))
        
        # 위험도 우선순위 정의
        risk_priority = ['Critical', 'High', 'Medium', 'Low']
        # 가장 높은 위험도 결정
        highest_risk = next((risk for risk in risk_priority if risk_level[risk] > 0), 'Unknown')
        # vuln 값을 설정
        grouped_data[ip_str]['vuln'] = f"{highest_risk}::{risk_level['Total']}"
    
    # risk_level 임시 컬럼 삭제
    for ip_str in grouped_data:
        del grouped_data[ip_str]['risk_level']
    
    # 최종 결과를 리스트로 변환
    grouped_data_list = list(grouped_data.values())
    
    return grouped_data_list

def getAssetCountService():
    ip = AssetList.objects.filter(match='O').values("ip_str").distinct().count()
    cloud = AssetList.objects.filter(match='O', tags__icontains='cloud').values("ip_str").distinct().count()
    
    software = AssetList.objects.filter(match='O').only('cpe23').exclude(cpe23=None)
    # software 파싱
    cpe23_list = []
    for item in software:
        clean_data(item)
        
        if item.cpe23 != "":
            # 문자열을 리스트로 변환
            cpe23 = ast.literal_eval(item.cpe23)
        else:
            cpe23 = item.cpe23
            
        cpe23_list.append(cpe23)

    software_list = []
    for sublist in cpe23_list:
        for software in sublist:
            software_list.append(software)

    software = len(software_list)
    
    domain = AssetList.objects.filter(match='O').only("hostnames").exclude(hostnames='[]')
    # domain 중복 처리 로직
    domain_list = []
    for item in domain:
        if isinstance(item.hostnames, str):
            # 문자열을 리스트로 변환
            hostnames = ast.literal_eval(item.hostnames)
        else:
            hostnames = item.hostnames
            
        domain_list.append(hostnames)
    # 중복된 호스트 이름 제거
    unique_domains = set()
    for sublist in domain_list:
        unique_domains.update(sublist)
    # 최종 결과를 리스트로 변환하고 count 계산
    unique_domains_list = list(unique_domains)
    domain = len(unique_domains_list)

    port = AssetList.objects.filter(match='O').exclude(port=None).count()
    app = 0
        
    result = {
        "ip": ip,
        "cloud": cloud,
        "software": software,
        "domain": domain,
        "port": port,
        "app": app
    }
    
    return result

def getAssetDetailsService(ip):
    datas = AssetList.objects.filter(match='O', ip_str=ip).only("tags", "collect_datetime", "ip_str", "asn", "org", "isp", "ssl", "hostnames", "os", "port", "cpe23", "product", "ftp").order_by('idx')
    
    # 그룹화하기 위한 딕셔너리
    grouped_data = defaultdict(lambda: {
        "status": None,
        "environment": None,
        "tags": [],
        "first_scaned": None,
        "last_scaned": None,
        "ip": None,
        "asn": None,
        "org": None,
        "isp": None,
        "related_assets": [],
        "hostname": [],
        "os": None,
        "port": [],
        "cpe": [],
        "product": []
    })
    
    ip_str = ''
    
    # 데이터 가공
    for item in datas:
        clean_data(item)
            
        ip_str = item.ip_str
        
        # 1회성 처리 컬럼
        if grouped_data[ip_str]['ip'] is None:
            grouped_data[ip_str]['ip'] = item.ip_str
            grouped_data[ip_str]['asn'] = item.asn
            grouped_data[ip_str]['first_scaned'] = item.collect_datetime
            grouped_data[ip_str]['last_scaned'] = item.collect_datetime
            grouped_data[ip_str]['org'] = item.org
            grouped_data[ip_str]['isp'] = item.isp
            grouped_data[ip_str]['os'] = item.os
            ### 임시처리 related_assets (ftp 컬럼 삭제도 필요 - orm)
            if item.ftp != "":
                assets = ast.literal_eval(item.ftp)
                grouped_data[ip_str]["related_assets"] += assets
            ###
        
        if '"cloud"' in item.tags:
            grouped_data[ip_str]['environment'] = 'cloud'
            
        if item.ssl != "":
            ssl_json = json.loads(item.ssl)
            # 값이 없다면 null 처리
            ssl_issuer_org = ssl_json.get('cert', {}).get('issuer', {}).get('O', 'null')
            ssl_subject_org = ssl_json.get('cert', {}).get('subject', {}).get('O', 'null')
            if ssl_issuer_org != "null":
                grouped_data[ip_str]["related_assets"].append(f'CERT(issuer)::{ssl_issuer_org}')
                
            if ssl_subject_org != "null":
                grouped_data[ip_str]["related_assets"].append(f'CERT(subject)::{ssl_subject_org}')
                
            
        # 다중 처리 컬럼
        if item.tags != "[]" and item.tags != "":
            tags = ast.literal_eval(item.tags)
            for tag in tags:
                grouped_data[ip_str]['tags'].append(tag)
                
        if item.hostnames != "[]" and item.hostnames != "":
            hostnames = ast.literal_eval(item.hostnames)
            for hostname in hostnames:
                grouped_data[ip_str]['hostname'].append(hostname)
                
        if item.cpe23 != "[]" and item.cpe23 != "":
            cpe23s = ast.literal_eval(item.cpe23)
            for cpe23 in cpe23s:
                grouped_data[ip_str]['cpe'].append(cpe23)
                
        if item.product != "":
            grouped_data[ip_str]['product'].append(item.product)
        
        if item.port != "":
            field_shodan_json = json.loads(item.field_shodan)
            protocol = field_shodan_json['module']
            grouped_data[ip_str]['port'].append(f'{protocol}::{int(item.port)}')
            

    # 중복 제거 처리
    grouped_data[ip_str]['tags'] = list(set(grouped_data[ip_str]['tags']))
    grouped_data[ip_str]['hostname'] = list(set(grouped_data[ip_str]['hostname']))
    grouped_data[ip_str]['related_assets'] = list(set(grouped_data[ip_str]['related_assets']))
    grouped_data[ip_str]['product'] = list(set(grouped_data[ip_str]['product']))
    grouped_data[ip_str]['cpe'] = list(set(grouped_data[ip_str]['cpe']))
    grouped_data[ip_str]['port'] = list(set(grouped_data[ip_str]['port']))
            
    # 최종 결과를 리스트로 변환
    grouped_data_list = list(grouped_data.values())
    
    return grouped_data_list


def getAssetRiskListService(ip):
    datas = AssetList.objects.filter(match='O', ip_str=ip).only("idx", "ip_str", "hostnames", "port", "tags", "vulns", "collect_datetime").exclude(vulns=None).order_by('idx')
    
    result = []
    for item in datas:
        clean_data(item)
        
        if item.hostnames != "":
            hostnames_list = ast.literal_eval(item.hostnames)
        # 취약점 파싱
        vulns_json = json.loads(item.vulns)
        count = 1 ### idx 임시 처리
        for cve_id, cve_data in vulns_json.items():
            risk_score = cve_data['cvss_v2']
            risk = "Unknown"
            if risk_score != None:
                if risk_score <= 3.9:
                    risk = 'Low'
                elif risk_score > 3.9 and risk_score <= 6.9:
                    risk = 'Medium'
                elif risk_score > 6.9 and risk_score <= 8.9:
                    risk = 'High'
                elif risk_score > 8.9:
                    risk = 'Critical'
            
            result.append({
                ### idx 임시처리
                "idx": f'{item.idx + 100}_{count}',
                ###
                "risk": risk,
                "ip": item.ip_str,
                "port": int(item.port),
                "domain": hostnames_list,
                "category": "Application",
                "title": cve_id,
                "exploit": "Unknown",
                "first_seen": item.collect_datetime,
                "last_seen": item.collect_datetime
            })
            count += 1 ### idx 임시 처리
    return result

def getRiskListService():
    datas = AssetList.objects.filter(match='O').only("idx", "ip_str", "hostnames", "port", "tags", "vulns", "collect_datetime").exclude(vulns=None).order_by('idx')
    
    result = []
    for item in datas:
        clean_data(item)
        
        if item.hostnames != "":
            hostnames_list = ast.literal_eval(item.hostnames)
        
        # 취약점 파싱
        vulns_json = json.loads(item.vulns)
        count = 1 ### idx 임시 처리
        for cve_id, cve_data in vulns_json.items():
            risk_score = cve_data['cvss_v2']
            risk = "Unknown"
            if risk_score != None:
                if risk_score <= 3.9:
                    risk = 'Low'
                elif risk_score > 3.9 and risk_score <= 6.9:
                    risk = 'Medium'
                elif risk_score > 6.9 and risk_score <= 8.9:
                    risk = 'High'
                elif risk_score > 8.9:
                    risk = 'Critical'
            
            result.append({
                ### idx 임시 처리
                "idx": f'{item.idx + 100}_{count}',
                ###
                "risk": risk,
                "ip": item.ip_str,
                "port": int(item.port),
                "domain": hostnames_list,
                "category": "Application",
                "title": cve_id,
                "exploit": "Unknown",
                "first_seen": item.collect_datetime,
                "last_seen": item.collect_datetime
            })
            
            count += 1 ### idx 임시 처리
    return result

def getRiskDetailService(ip, port, title, idx):
    #datas = AssetList.objects.filter(match='O',ip_str=ip,port=port).only("ip_str", "hostnames", "port", "tags", "vulns", "collect_datetime").exclude(vulns=None).order_by('idx')
    
    ### idx 임시 처리
    idx = idx.split('_')
    idx[0] = int(int(idx[0]) - 100)
    datas = AssetList.objects.filter(match='O',idx=idx[0]).only("ip_str", "hostnames", "port", "tags", "vulns", "collect_datetime").exclude(vulns=None).order_by('idx')
    ###
    
    result = []
    for item in datas:
        clean_data(item)
        
        count = 1 ### idx 임시 처리
        
        vulns_json = json.loads(item.vulns)
        for cve_id, cve_data in vulns_json.items():
            # 조건 처리
            if int(idx[1]) == count: ### idx 임시 처리
            #if cve_id == title:
                risk_score = cve_data['cvss_v2']
                risk = "Unknown"
                if risk_score != None:
                    if risk_score <= 3.9:
                        risk = 'Low'
                    elif risk_score > 3.9 and risk_score <= 6.9:
                        risk = 'Medium'
                    elif risk_score > 6.9 and risk_score <= 8.9:
                        risk = 'High'
                    elif risk_score > 8.9:
                        risk = 'Critical'
        
                result.append({
                    "risk": risk,
                    "category": "Applcation",
                    "issue_status": "Resolved",
                    "cve": cve_id,
                    "impact": "Unknown",
                    "first_seen": item.collect_datetime,
                    "last_seen": item.collect_datetime,
                    "title": cve_id,
                    "description": cve_data.get('summary', None),
                    "solution": "Apply the latest updates and security patches",
                    "security_advisory": cve_data.get('references', None)
                })
            count += 1 ### idx 임시 처리 
    return result