
# API(RISK)
## 1. 전체 취약점 목록 호출
<br>메뉴: Asset List > Asset Details > Risk 
<br>URI: /risk/all_vuln_list/
<br>Method: GET
<br>Options:
<br>page (선택적): 페이지네이션 처리 (기본값: 1)

## 2. 취약점 상세 결과 호출
<br>메뉴: Risk Management > Risk List > Risk Detail
<br>URI: /risk/vuln_detail/?idx=1
<br>Method: GET
<br>매개변수 : idx (필수)

## 3. 카테고리별 취약점 개수 호출
<br>메뉴: Asset List > Asset Details > Risk 그림
<br>URI: /risk/category_result/
<br>Method: GET

## 4. 리스크별 취약점 개수 호출
<br>메뉴: Asset List > Asset Details > Risk 표
<br>URI: /risk/risk_result/
<br>Method: GET

## 5. IP별 취약점 개수 호출
<br>메뉴: Asset List (Vuln 컬럼)
<br>URI: /risk/ip_result/
<br>Method: GET

# API(Assets)
## 1. Asset List 호출
<br>* URI: /asset/list?page=1
<br>
<br>* Method: GET
<br>
<br>* Options:
<br>    * page(필수X): 페이지네이션 처리(default: 1)

## 2. Asset Count 호출
<br>* URI: /asset/count
<br>
<br>* Method: GET

## 3. Asset Detail 호출
<br>* URI: /asset/detail?ip=1.1.1.1
<br>
<br>* Method: GET
<br>
<br>* Options:
<br>    * ip(필수O): 검색할 ip

## 4. Asset > Risk List 호출
<br>* URI: /asset/risk/list?ip=1.1.1.1
<br>
<br>* Method: GET
<br>
<br>* Options:
<br>    * ip(필수O): 검색할 ip


## 5. Risk List 호출
<br>* URI: /asset/risk/list?page=1
<br>
<br>* Method: GET
<br>
<br>* Options:
<br>    * page(필수X): 페이지네이션 처리(default: 1)


## 6. Risk Detail 호출
<br>* URI: /asset/risk/detail?idx=130_1
<br>
<br>* Method: GET
<br>
<br>* Options:



# django guide

## django start
<br>    python manage.py runserver

## DBMS Config Setting
<br>    setting.py 내부 수정

## model updated (models.py 규격 자동 생성)
<br>    python manage.py inspectdb > models.py

## DBMS migration (DBMS 관련 데이터 업데이트가 있는 경우 아래 명령어 실행)
<br>    python manage.py makemigrations
<br>    python manage.py migrate

## 디렉토리 생성 관련
<br>    1. python manage.py startapp {name}
<br>    2. 생성된 디렉터리에 serializers.py, urls.py 생성(api\\ 경로에 있는 파일 복사해도 됨)
<br>    3. api_server\\settings.py 내부 INSTALLED_APPS에 생성된 디렉터리 추가
<br>    4. api_server\\urls.py 내부 urlpatterns에 라우팅 처리 코드 추가
<br>    6. 생성된 디렉터리에서 개발 진행

</br>
</br>



# 현재 사용안되는 API 리스트
<br>메뉴 X
<br>URI /risk/dns/
<br>Method: GET
<br>Options:
<br>page` (선택적): 페이지네이션 처리 (기본값: 5)
<br>
<br>2. Domain 데이터 호출
<br>메뉴: X
<br>URI: /risk/domain/
<br>Method: GET
<br>Options:
<br>page (선택적): 페이지네이션 처리 (기본값: 5)
<br>
<br>3. Git 데이터 호출
<br>메뉴: X
<br>URI: /risk/git/
<br>Method: GET
<br>Options:
<br>page (선택적): 페이지네이션 처리 (기본값: 1)
<br>
<br>4. SSL 데이터 호출
<br>메뉴: X
<br>URI: /risk/ssl/
<br>Method: GET
<br>Options:
<br>page (선택적): 페이지네이션 처리 (기본값: 1)