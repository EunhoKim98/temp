from django.http import JsonResponse
from rest_framework.decorators import api_view
from django.core.validators import URLValidator, validate_ipv4_address
from django.core.exceptions import ValidationError
from .models import ShodanDup
import requests

def request_flask(domain):
    res = requests.get(url=f'http://test.com?domain={domain}')
    if res.status_code != 200:
        print("Flask Request ERROR")

@api_view(['GET'])
def search(request):
    domain = request.GET.get('domain', '').strip()
    
    if not domain.startswith(('http://', 'https://')):
        domain = 'http://' + domain

    url_validator = URLValidator()
    domain_name = domain.split('//')[-1] 

    try:
         # 도메인 유효성 검증
        url_validator(domain)
        validate_ipv4_address(domain_name) 
        
        #Flask 서버에 요청
        #request_flask(domain_name)
        
        
        return JsonResponse({"status": "error", "message": "Invalid IP address or Domain"})
    
    except ValidationError:
        return JsonResponse({"status": "error", "message": "Invalid IP address or Domain"}) 

@api_view(['GET'])
def finish(request):
    ip = request.GET.get('ip')
    recent_asset = ShodanDup.objects.filter(ip=ip).order_by('-timestamp').first()
 
