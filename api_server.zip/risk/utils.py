from django.db.models import Max
from .models import VulnDetail, VulnList

# 최대 request_time을 가진 VulnList 레코드를 가져오는 함수
def get_latest_data():
    # 모든 IP에 대해 최대 request_time을 계산
    max_request_times = VulnList.objects.values('ip').annotate(max_request_time=Max('request_time'))

    # 최대 request_time을 가진 VulnList 객체를 조회
    VulnList_records = VulnList.objects.none()  # 빈 QuerySet으로 초기화
    
    for entry in max_request_times:
        # 각 IP에 대해 최대 request_time을 가진 레코드를 가져옴
        records = VulnList.objects.filter(ip=entry['ip'], request_time=entry['max_request_time'])
        VulnList_records = VulnList_records | records  # QuerySet 합치기
    
    return VulnList_records  # QuerySet 반환


# 각 카테고리별 취약점 개수를 구하는 함수
def count_vuln_category(serializer):
    categories = ['ssl', 'host', 'domain', 'etc', 'cloud', 'application']

    # 카테고리별 카운트를 초기화
    category_counts = {category: 0 for category in categories}

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        category = record.get('category', '').lower()  # 소문자로 변환하여 가져오기
        if category in category_counts:
            category_counts[category] += 1

    return category_counts

# IP별 취약점 개수를 세는 함수
def count_vuln_ip(serializer):
    risk_order = {
        'Critical': 4,
        'High': 3,
        'Medium': 2,
        'Low': 1,
    }

    ip_counts = {}

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        ip = record['ip']
        risk = record.get('risk', 'Low')

        if ip not in ip_counts:
            ip_counts[ip] = {
                'vulnerability_count': 0,
                'highest_risk': 0
            }

        ip_counts[ip]['vulnerability_count'] += 1
        ip_counts[ip]['highest_risk'] = max(ip_counts[ip]['highest_risk'], risk_order.get(risk, 0))

    # 위험 수준에 따라 이름의 첫 글자로 변환
    risk_mapping = {v: k[0] for k, v in risk_order.items()}

    return [{'ip': ip,
             'vulnerability_count': data['vulnerability_count'],
             'highest_risk': risk_mapping.get(data['highest_risk'], 'N')}
            for ip, data in ip_counts.items()]
    
# 각 카테고리와 리스크 조합으로 취약점 개수를 구하는 함수
def count_vuln_risk(serializer):
    risk_levels = ['Critical', 'High', 'Medium', 'Low']
    categories = ['ssl', 'host', 'domain', 'etc', 'cloud', 'application']  # 'application' 카테고리 추가

    # 총 카운트 및 상세 카운트 초기화
    total_counts = {f"{risk.lower()}_total_count": 0 for risk in risk_levels}
    
    # 모든 리스크와 카테고리 조합을 초기화
    detail_counts = {f"{risk.lower()}_{category}": 0 for risk in risk_levels for category in categories}

    # 직렬화된 레코드를 기반으로 카운트
    for record in serializer:
        risk = record.get('risk')  # risk 필드 가져오기
        category = record.get('category', '').lower()  # category 필드를 소문자로 가져오기

        if risk in risk_levels:
            total_counts[f"{risk.lower()}_total_count"] += 1

            # 카테고리별 카운트 추가
            if category in categories:
                detail_counts[f"{risk.lower()}_{category}"] += 1

    # 애플리케이션 카운트 추가
    for record in serializer:
        category = record.get('category', '').lower()  # 카테고리를 소문자로 가져오기
        risk = record.get('risk')  # 리스크 가져오기

        # 애플리케이션 카운트 추가
        if category in ['application(web)', 'application(mobile)', 'application']:
            if risk in risk_levels:
                detail_counts[f"{risk.lower()}_application"] += 1

    return {
        'total_counts': total_counts,
        'detail_counts': detail_counts
    }
