from rest_framework.decorators import api_view
from rest_framework.pagination import PageNumberPagination
from rest_framework.response import Response
from .models import VulnList
from .serializers import CombineVulnListSerializer
from pprint import pprint
from rest_framework import status
from .utils import get_latest_data, count_vuln_category, count_vuln_ip, count_vuln_risk
PAGE_SIZE = 100

# 전체 취약점 목록을 페이지네이션하여 반환하는 API 뷰
@api_view(['GET'])
def get_all_vuln_list(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    VulnList_records = get_latest_data()  # 최대 request_time을 가진 레코드 조회

    # 페이지네이션 적용
    result_page = paginator.paginate_queryset(VulnList_records, request)

    # 직렬화
    serializer = CombineVulnListSerializer(result_page, many=True)

    return paginator.get_paginated_response(serializer.data)

# IDX별 취약점 상세 결과를 반환하는 API 뷰
@api_view(['GET'])
def get_vuln_by_idx(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    idx = request.query_params.get('idx')

    if idx is None:
        return Response({"detail": "idx parameter is required."}, status=status.HTTP_400_BAD_REQUEST)

    try:
        # 해당 idx에 맞는 취약점 상세 정보 조회
        vuln_record = VulnList.objects.filter(pk=idx)

        if not vuln_record.exists():
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        # 페이지네이션 적용
        result_page = paginator.paginate_queryset(vuln_record, request)

        # 데이터를 직렬화
        serializer = CombineVulnListSerializer(result_page, many=True)

        return paginator.get_paginated_response(serializer.data)

    except VulnList.DoesNotExist:
        return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

# IP별 취약점 개수를 반환하는 API 뷰 (페이지네이션 적용)
@api_view(['GET'])
def get_ip_counts_view(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    VulnList_records = get_latest_data()  # 최대 request_time을 가진 레코드 조회
    serializer = CombineVulnListSerializer(VulnList_records, many=True)
    
    ip_counts = count_vuln_ip(serializer.data)  # 직렬화된 데이터 사용

    # 페이지네이션 적용
    result_page = paginator.paginate_queryset(ip_counts, request)
    
    return paginator.get_paginated_response(result_page)


# 카테고리별 취약점 개수를 반환하는 API 뷰 (페이지네이션 적용)
@api_view(['GET'])
def get_category_counts_view(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    VulnList_records = get_latest_data()  # 모든 VulnList 레코드를 가져옵니다.
    serializer = CombineVulnListSerializer(VulnList_records, many=True)
    
    category_counts = count_vuln_category(serializer.data)  # 직렬화된 데이터 사용

    # 카테고리별 카운트를 리스트로 변환하여 페이지네이션 적용
    category_list = [{'category': category, 'count': count} for category, count in category_counts.items()]
    result_page = paginator.paginate_queryset(category_list, request)

    # 결과에서 results만 반환
    return Response(result_page)

# 리스크별 취약점 개수를 반환하는 API 뷰
@api_view(['GET'])
def get_risk_counts_view(request):
    paginator = PageNumberPagination()
    paginator.page_size = PAGE_SIZE

    # 최대 request_time을 가진 VulnList 레코드를 가져옵니다.
    VulnList_records = get_latest_data().order_by('idx')  # 적절한 필드로 정렬

    # 직렬화
    serializer = CombineVulnListSerializer(VulnList_records, many=True)

    # 페이지네이션 적용
    result_page = paginator.paginate_queryset(serializer.data, request)

    # 리스크별 취약점 개수 계산
    risk_counts = count_vuln_risk(result_page)  # 직렬화된 데이터로 카운트

    return paginator.get_paginated_response(risk_counts)  # 결과를 반환