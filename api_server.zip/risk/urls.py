from django.urls import path
from . import views

urlpatterns = [
    path('all_vuln_list/', views.get_all_vuln_list, name="get_all_vuln_list"),
    path('vuln_detail/', views.get_vuln_by_idx, name='vuln-detail'),
    path('category_result/', views.get_category_counts_view, name='get_category_count'),
    path('risk_result/', views.get_risk_counts_view, name='get_risk_count'),
    path('ip_result/', views.get_ip_counts_view, name='get_ip_count'),
]
