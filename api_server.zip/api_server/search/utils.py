from django.db.models import OuterRef, Subquery
from .models import VulnDetail, VulnListSearch


# 최대 request_time을 가진 VulnList 레코드를 가져오는 함수
def get_latest_data(request_time):
    # 각 IP에 대해 최대 request_time을 서브쿼리로 가져옴
    VulnList_records = VulnListSearch.objects.filter(request_time=request_time)

    return VulnList_records  # QuerySet 반환