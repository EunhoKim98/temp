
from rest_framework import serializers
from .models import AssetList, VulnDetail

class AssetListSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetList
        fields = '__all__'  # 또는 필요한 필드명을 지정


class CombineVulnListSerializer(serializers.Serializer):
    threat_id = serializers.CharField()
    ip = serializers.IPAddressField()
    port = serializers.IntegerField()
    domain = serializers.CharField()
    category = serializers.CharField()
    issue_status = serializers.CharField()
    screenshot = serializers.URLField()
    datetime = serializers.DateTimeField()
    title = serializers.CharField(allow_blank=True, required=False)
    risk = serializers.CharField(allow_blank=True, required=False)
    description = serializers.CharField(allow_blank=True, required=False)
    security_advisory = serializers.CharField(allow_blank=True, required=False)
    impact = serializers.CharField(allow_blank=True, required=False)
    cve = serializers.CharField(allow_blank=True, required=False)
    exploit = serializers.CharField(allow_blank=True, required=False)
    request_time = serializers.CharField(allow_blank=True, required=False)

    def to_representation(self, instance):
        representation = super().to_representation(instance)

        # VulnDetail에서 필요한 값을 가져오기 위한 쿼리
        vuln_detail = VulnDetail.objects.filter(threat_id=instance.threat_id).first()

        # VulnDetail이 존재하는 경우, 해당 필드 값을 가져옴
        if vuln_detail:
            representation['title'] = representation['title'] or (vuln_detail.title or "")
            representation['description'] = representation['description'] or (vuln_detail.description or "")
            representation['impact'] = representation['impact'] or (vuln_detail.impact or "")
            representation['risk'] = representation['risk'] or (vuln_detail.risk or "")
            representation['cve'] = representation['cve'] or (vuln_detail.cve or "")
            representation['exploit'] = representation['exploit'] or (vuln_detail.exploit or "")
        else:
            representation['title'] = ""
            representation['description'] = ""
            representation['impact'] = ""
            representation['risk'] = ""
            representation['cve'] = ""
            representation['exploit'] = ""

        return representation
