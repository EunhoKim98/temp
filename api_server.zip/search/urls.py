
from django.urls import path
from . import views 

urlpatterns = [
    path('check/', views.check, name='check'),
    path('register/', views.register, name='register'), 
]
    
    # 2페이지
    #자산 추가 API(프론트에서 신규 자산이 추가되는 경우 Flask에 전달해서 DBMS에 쌓는 과정 - response JSON X, status)
    #자산 뿌려주는 API (프론트에서 약 10초 간격으로 요청되는 API -> DBMS에 있는 데이터를 JSON으로 깔끔하게 파싱해서 던져줘야됨)
    
    # 3페이지(위협 risk list)
    #위협 뿌려주는 API
