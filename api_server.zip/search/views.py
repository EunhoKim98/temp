from django.http import JsonResponse
from rest_framework.decorators import api_view
from django.core.validators import URLValidator, validate_ipv4_address
from django.core.exceptions import ValidationError
from rest_framework.response import Response
from .models import AssetListSearch, VulnListSearch, VulnDetail
from .serializers import AssetListSerializer, CombineVulnListSerializer
from django.db.models import Subquery, OuterRef, F
from django.db.models.functions import Coalesce
import requests
import ipaddress
from asset.services import getAssetDetailsService
from .utils import get_latest_data

# 설명: 1번 페이지. 도메인에 대한 유효성을 검증하고, Flask 서버에 요청을 보낸 후 결과를 반환합니다.
# Args: request: HTTP 요청 객체.
# Returns: Response: JSON 형태의 응답.
@api_view(['GET'])
def check(request):
    ip_or_domain = request.GET.get('asset', '').strip()

    # URL 형식으로 변환
    if not ip_or_domain.startswith(('http://', 'https://')):
        ip_or_domain = f"http://{ip_or_domain}"

    # 유효성 검증
    if not validate_ip_or_domain(ip_or_domain):
        return JsonResponse({"status": "error", "message": "Invalid IP address or Domain"}, status=400)

    # http 또는 https 제거
    ip_or_domain = ip_or_domain.replace('http://', '', 1).replace('https://', '', 1)

    # Flask 서버에 요청
    result = request_flask(ip_or_domain, 'search')
    
    if result is None:
        return JsonResponse({"status": "error", "message": "Request failed"}, status=500)
    
    return JsonResponse(result, status=200)


# 설명: Flask 서버에 도메인 정보를 전송하고, 응답으로 받은 IP 주소를 바탕으로 데이터를 생성합니다.
# Args: domain (str): 요청할 도메인.
# Returns: dict or None: Flask 서버의 응답으로부터 얻은 데이터 또는 None.
def request_flask(ip_or_domain, path):
    res = requests.get(url=f'http://13.211.203.59:5000/{path}?asset={ip_or_domain}', timeout=600) 
    print('============================')
    
    print(res.text)
    temp = res.json()
    print('============================')
    print(res.status_code)
    if res.status_code == 200:
        
        # 2번 페이지라면 flask 상태 값만 리턴
        if path == 'regist':
            return temp['success']
        
        ip = temp['data']['ip']
        request_time = temp['data']['request_time']
        result = make_data(ip, request_time)  # IP 주소를 바탕으로 데이터를 생성
        return result
    else:
        print('[*] Flask Server Request Error')
        return None
    ip = "101.1.53.136"
    result = make_data(ip)
    return result


# 설명: 도메인 유효성을 검증합니다.
# Args: domain (str): 검증할 도메인.
# Returns: bool: 유효한 도메인일 경우 True, 아닐 경우 False.
def validate_ip_or_domain(domain):
    url_validator = URLValidator()
    try:
        url_validator(domain)
        return True
    except ValidationError:
        pass
    
    try:
        ipaddress.ip_address(domain)
        return True  # IP 주소가 유효함
    except ValueError:
        pass
    
    return False

# 설명: 주어진 IP 주소를 바탕으로 자산 정보와 취약점 세부정보를 검색하여 응답합니다.
# Args: ip (str): 검색할 IP 주소.
# Returns: Response: 자산 및 취약점 정보를 포함한 JSON 응답.
def make_data(ip, request_time):
    if not ip:
        return Response({"error": "IP address is required."}, status=400)
    
    # 자산 파싱
    recent_asset = getAssetDetailsService(ip, request_time=request_time)

    # 최신 VulnList 레코드 가져오기
    vuln_list_records = get_latest_data()  # 최신 데이터 가져오기
    vuln_list_records = vuln_list_records.filter(threat_id__in=VulnDetail.objects.values_list('threat_id', flat=True))
    
    # VulnList 직렬화
    vuln_serializer = CombineVulnListSerializer(vuln_list_records, many=True).data

    # 최신 datetime을 가진 취약점 필터링
    latest_vuln_details = sorted(vuln_serializer, key=lambda x: x['datetime'], reverse=True)

    if latest_vuln_details:
        # 가장 최신의 데이터를 가져옴
        latest_datetime = latest_vuln_details[0]['datetime']
        vuln_details = [vuln for vuln in latest_vuln_details if vuln['datetime'] == latest_datetime]
    else:
        vuln_details = []  # 취약점이 없으면 빈 리스트

    if recent_asset is not None:
        asset_serializer = AssetListSerializer(recent_asset).data
        
        # 응답 데이터 구조 생성
        response_data = {
            "result": {
                "asset": asset_serializer,
                "vuln_detail": vuln_details
            }
        }
        
        return Response(response_data, status=200)
    
    else:
        return Response({"message": "No asset found for the provided IP."}, status=404)



# 설명: 주어진 취약점 레코드를 직렬화하여 JSON 형태로 변환합니다.
# Args: records (QuerySet): 직렬화할 취약점 레코드의 쿼리셋.
# Returns: list: 직렬화된 취약점 데이터의 리스트.
def serialize_combine_records(records):
    serializer = CombineVulnListSerializer(records, many=True)
    return serializer.data


@api_view(['GET'])
def register(request):
    ip_or_domain = request.GET.get('asset', '').strip()

    # ip or domain 유효성 검증 start
    ip_or_domain = f"http://{ip_or_domain}" if not ip_or_domain.startswith(('http://', 'https://')) else ip_or_domain

    if not validate_ip_or_domain(ip_or_domain):
        return JsonResponse({"status": "error", "message": "Invalid IP address or Domain"})
    
    if ip_or_domain.startswith('http://'):
        ip_or_domain = ip_or_domain.replace('http://', '', 1)
    elif ip_or_domain.startswith('https://'):
        ip_or_domain = ip_or_domain.replace('https://', '', 1)
    # ip or domain 유효성 검증 end

    result = request_flask(ip_or_domain, 'regist')
    
    return JsonResponse({"status": "success", "message": "Regist success"}) if result != None else JsonResponse({"status": "error", "message": "Request failed"})

