from django.db.models import Max
from .models import VulnDetail, VulnListSearch

# 최대 request_time을 가진 VulnList 레코드를 가져오는 함수
def get_latest_data():
    # 모든 IP에 대해 최대 request_time을 계산
    max_request_times = VulnListSearch.objects.values('ip').annotate(max_request_time=Max('request_time'))

    # 최대 request_time을 가진 VulnList 객체를 조회
    VulnList_records = VulnListSearch.objects.none()  # 빈 QuerySet으로 초기화
    
    for entry in max_request_times:
        # 각 IP에 대해 최대 request_time을 가진 레코드를 가져옴
        records = VulnListSearch.objects.filter(ip=entry['ip'], request_time=entry['max_request_time'])
        VulnList_records = VulnList_records | records  # QuerySet 합치기
    
    return VulnList_records  # QuerySet 반환
