from django.urls import path
from . import views

urlpatterns = [
    path('list', views.getAssetList, name="asset_list"),
    path('count', views.getAssetCount, name="asset_count"),
    path('detail', views.getAssetDetails, name="asset_detail"),
    path('risk/list', views.getAssetRiskList, name="asset_risk_list"),
    path('risk/list', views.getRiskList, name="risk_list"),
    path('risk/detail', views.getRiskDetail, name="risk_detail")
]
