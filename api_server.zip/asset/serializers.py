from rest_framework.serializers import ModelSerializer
from .models import  AssetList
        
class AssetListSerializer(ModelSerializer):
    class Meta:
        model = AssetList
        fields = ["ip_str", "hostnames", "org", "location", "port", "tags", "collect_datetime"]
